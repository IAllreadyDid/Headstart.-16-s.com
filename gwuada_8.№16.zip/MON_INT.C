

/*
    GWMON Parallel Ada Monitor for 386/486 PCs   
    Copyright (C) 1993, Charles W. Kann  & Michael Bliss Feldman
                        ckann@seas.gwu.edu mfeldman@seas.gwu.edu
 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include <stdio.h>
#include <signal.h>
#include "ed.h"
static void ctrl_break()
{
	CWK_CLEANUP_MON(1);
    	signal( SIGINT, ctrl_break );
}
void GWU_GET_MON()
{
    int ch;
    signal( SIGTERM, ctrl_break );
    signal( SIGINT, ctrl_break );
    CWK_INIT_MON();
    CWK_FIRST_SETUP();
    if ( task_monitor )
    	CWK_TASK_SETUP();
    else
    {
    	CWK_SEQ_SETUP();
    	CWK_SETUP_WINDOWS();
    	CWK_Resize_Window();
    }
}
