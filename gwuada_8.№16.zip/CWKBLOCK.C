/*
    GWMON Parallel Ada Monitor for 386/486 PCs   
    Copyright (C) 1993, Charles W. Kann  & Michael Bliss Feldman
                        ckann@seas.gwu.edu mfeldman@seas.gwu.edu
 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include "ed.h"
#include "keydef.h"

void CWK_CREATE_BLOCK(block_no, block_name, block_file)
int block_no;
char *block_name;
char *block_file;
{
    char msg[100];
    int ch;

    if ( block_no > MAX_BLKS ) {
	printf("Can't work with more than %d blocks, (%d)...", MAX_BLKS-1,
			block_no);
	}
    /*
	Find the block particulars in the block file (For now, hard code them)
    */
	CWK_BLKS[block_no].TN = malloc( strlen(block_name)+1 );
	strcpy( CWK_BLKS[block_no].TN, block_name );
	CWK_BLKS[block_no].FL = 1;
	CWK_BLKS[block_no].LL = 10000;
	CWK_BLKS[block_no].FLOS = 0;
	CWK_BLKS[block_no].CL = 0;
	CWK_BLKS[block_no].MON = CWK_CREATE_MON_WIN(CWK_BLKS[block_no].TN, 
		(monitor_type == 1) ? 1 : 0 );
        CWK_BLKS[block_no].FD = CWK_LOAD_FILE(block_file);
}
