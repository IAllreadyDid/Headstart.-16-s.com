

/*
    GWMON Parallel Ada Monitor for 386/486 PCs   
    Copyright (C) 1993, Charles W. Kann  & Michael Bliss Feldman
                        ckann@seas.gwu.edu mfeldman@seas.gwu.edu
 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include "ed.h"

int step_rate = 4;	        /* The loop counter for busy waiting */
int delay_scaling_factor = 5000;
int delay_array[MAX_DELAY] = { 0, 1, 2, 4, 7, 12, 24, 48, 90, 180 };
int task_monitor = 0;		/* Flag set to 0 if this this a sequential */
int exception_monitor = 1;	/* Flag set if exceptions should be reported */
int monitor_exec_time = 1;	/* Flag set if execution time should be */
				/* on the last line on the screen */
int task_step = 0;		/* Flag set if task step monitoring is on */
int step_monitor = 1;		/* Flag set if line step monitoring is on */
int  Time_To_Read_Key = 10;	/* The number of "ticks" between looking for */
				/* a key press */
int Exec_Report_Time = 2000;    /* Amount of time till the execution time is */
				/* Reported on the execution %  */
int monitor_type = 1;		/* Monitor type, 0 is no monitor, 1 is */
				/* monitoring lines, 2 is exec % */
int monitor_window_type = 0;	/* Type of monitor windows with monitor_type=1*/
				/*     0 = 4 windows, 1 = 2 windows horizonal */
				/*     2 = 2 windows veritcal, 3 = 1 window   */
int type_of_delay = 0;		/* Type of delay with 0 = real time (normal)  */
				/*    and 1 - relative to clock ticks         */
int seconds_per_tick = 1000;	/* Number of seconds per clock tick for type */
				/* of delay = 2 */
int Block_Level = 0;		/* The number of program blocks which are    */
				/* active                                    */
int WIN_SIZE = 5;		/* The number of lines in the window for the */
				/* line moitoring.  Ie. 5 for window type 0  */
				/* and 1, 11 for types 2 and 3               */
int LINE_SIZE = 28;		/* The length of each line in the monitor    */
				/* If the monitor type is 0 or 1, it is 28   */
				/* characters, otherwise it is 68            */
int Large_Monitor = 0;		/* Flag which determines whether we are using*/
				/* the large monitor screen (ie program      */
				/* output 2 lines ) or small monitor (program*/
				/* output 10 lines )                         */
int Windows_Used = 1;		/* The number of Monitor windows used by the */
				/* monitor                                   */
long Run_Total_Time = 0; 	/* Total run time (lines) for this run */
TASK_REC  CWK_TASKS[MAX_TSKS+1];
TASK_REC  CWK_BLKS[MAX_BLKS+1];
MON_REC   CWK_MONS[MAX_BLKS+1];

