--
--  Screen_IO contains a task which controls the concurrency in the
--  I/O to the screen.
--
WITH Screen;
USE Screen;
PACKAGE Screen_IO IS

    SUBTYPE Height   IS Screen.Height;
    SUBTYPE Width    IS Screen.Width;
    SUBTYPE Position IS Screen.Position;
    
    TASK Terminal IS
        ENTRY WriteAt(Where: Screen.Position; What : String );
    END Terminal;

END Screen_IO;
