--
-- Creatures is the package in which worms resides.  
--

PACKAGE Creatures IS

    TASK TYPE Worm IS 
        ENTRY Init_Worm( Symbol : IN CHARACTER  );
    END Worm;

    TYPE Coordinate IS
        RECORD
            x,y : Integer;
        END RECORD;

    Maximum_xy : Coordinate;
    Minimum_xy : Coordinate;

END Creatures;
