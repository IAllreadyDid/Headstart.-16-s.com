PACKAGE Random IS

-- Simple pseudo-random number generator package.
-- Adapated from the Ada literature by
-- Michael B. Feldman, The George Washington University, November 1990.

  PROCEDURE Set_Seed (N : Positive);

  FUNCTION  Unit_Random RETURN Float;

    --returns a float >=0.0 and <1.0

  FUNCTION  Random_Int (N : Positive) RETURN Positive;

    --return a random integer in the range 1..N

END Random;

