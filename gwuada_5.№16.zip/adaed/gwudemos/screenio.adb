--
--  Implementation of the Screen_IO package
--

WITH Text_IO;
WITH Screen;
PACKAGE BODY Screen_IO IS

  TASK BODY Terminal IS

  BEGIN
    Screen.ClearScreen;
    LOOP
      SELECT
        ACCEPT WriteAt(Where: Screen.Position; What : String) DO
          Screen.MoveCursor(To => Where);
          Text_IO.Put( What );
        END WriteAt;
      OR
        TERMINATE;
      END SELECT;
    END LOOP;
  END Terminal;

END Screen_IO;
