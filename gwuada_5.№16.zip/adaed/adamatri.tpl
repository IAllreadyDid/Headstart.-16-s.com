TYPE $ IS ARRAY(_.._,_.._) OF _;
