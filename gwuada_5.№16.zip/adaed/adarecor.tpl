TYPE $ IS RECORD
	-- Fields
	END RECORD;
