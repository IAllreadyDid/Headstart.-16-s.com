CASE $ IS
	WHEN _ =>
		
	WHEN OTHERS =>
		NULL;
END CASE;
