TASK $ IS
	ENTRY _;
END;

TASK BODY _ IS
	-- Declarative part
BEGIN
	-- statements
END;