WITH Spider; Use Spider;
PROCEDURE Drawing4 IS 
BEGIN 
Reset; 
Step;    -- First, insert "Turn;" before this line.
Step;
Step;
Turn;
Step;    -- Second, insert "Cyan;" before this line.
Step;
Step;
Step;
Turn;
Step;    -- Third, insert "Green;" before this line.
Step;
Step;
Step;
Black;
Turn;
Step;
Green;
Turn;
Turn;
Turn;
Step;
Turn;
Black;
Step;
Green;
Step;
Black;
Turn;
Step;
Green;
Step;
Black;
Step;
Turn;
Step;
Red;
Turn;
Step;
Quit;
END Drawing4;
