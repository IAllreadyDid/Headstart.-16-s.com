TYPE $ ARRAY(_.._) OF <type>;
