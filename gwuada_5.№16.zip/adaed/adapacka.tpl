PACKAGE $ IS
	-- Basic declarative item
	-- ...
--PRIVATE
-- Basic declarative item
END;

PACKAGE BODY _ IS
	-- Declarative part
--[BEGIN
	-- Statements
END;
