--  -----------------------------------------------------------------------
--  Title:       elementary_functions_exceptions
--  Last Mod:    Thu Apr 19 11:21:05 1990
--  Author:      Vincent Broman <broman@nosc.mil>
--		 copying from the the SIGAda NumWG proposal
--   Copyright 1990 Vincent Broman
--     Permission granted to copy, modify, or compile this software for
--   one's own use, provided that this copyright notice is preserved intact.
--     Permission granted to distribute compiled binary copies of this
--   software which are linked in with some other application.
--     Permission granted to distribute other copies of this software,
--   provided that (1) any copy which is not source code, i.e. not in the
--   form in which the software is usually maintained, must be accompanied
--   by a copy of the source code from which it was compiled, and (2) the
--   one distributing it must refrain from imposing on the recipient
--   further restrictions on the distribution of this software.
--   
--  Visibility:  withed by users of standard math library functions
--  Description: 
--
--       The purpose of this package is (presently) to define a single
--       exception that may be raised by any instantiation of
--       GENERIC_ELEMENTARY_FUNCTIONS when a function in it receives an
--       argument that violates its mathematical domain definition.  The
--       package resulting from each of those instantiations exports an
--       exception of the same name which is a renaming of this one.
--
--  Note:
--
--       Additional standards to be proposed in the future may add other
--       exceptions to this package.
--
--  -----------------------------------------------------------------------
--
package elementary_functions_exceptions is

    argument_error : exception;

end elementary_functions_exceptions;

-- $Header: elem_func_exceptions_s.ada,v 3.13 90/04/19 12:33:31 broman Rel $
