WITH Text_IO; USE Text_IO;

PROCEDURE $ IS
	-- Declarations here
BEGIN
	NULL; -- Statements here
END;

