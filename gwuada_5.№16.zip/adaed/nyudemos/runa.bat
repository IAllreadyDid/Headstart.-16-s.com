adacomp -v  -nl demolib spath
adabind -l demolib
adaexec -l demolib
