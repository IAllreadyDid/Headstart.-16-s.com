pragma Form_Set(nasa_standard);
--           Test program for Meridian Ada compiler.            --
--        This program prints the numbers from 1 to 10.         --
--      Copyright (C) 1986 Meridian Software Systems, Inc.      --
 
with ada_io; use ada_io;
procedure simple is
begin
for i in 1..10 loop
put(i);
put(' ');
end loop;
new_line;
end;
