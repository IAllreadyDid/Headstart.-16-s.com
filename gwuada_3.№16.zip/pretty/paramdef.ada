         pragma Form_Set (SPECIAL);
         pragma Form_Set (Page_Width => 80);
         pragma Form_Set (Right_Comment_Column => 50);
         pragma Form_Set (Colon_Offset => 15);
         pragma Form_Set (Value_Offset => 15);
         pragma Form_Set (Assign_Offset => 15);
         pragma Form_Set (Pointer_Offset => 15);
         pragma Form_Set (Indentation => 3);
         pragma Form_Set (Using_Half_Indentation =>  TRUE);
         pragma Form_Set (Using_Reverse_Indentation => TRUE);
         pragma Form_Set (Types_Case =>  CAPITALIZE_FIRST);
         pragma Form_Set (Enumeration_Case =>  UPPER_CASE);
         pragma Form_Set (Identifier_Case =>  CAPITALIZE_FIRST);
         pragma Form_Set (Using_Echeloned_Declarations =>  False);
         pragma Form_Set (Using_Echeloned_Assigns =>  False);
         pragma Form_Set (Using_Colon_Alinement =>  False);
         pragma Form_Set (Using_Value_Alinement =>  False);
         pragma Form_Set (Using_Assign_Alinement =>  False);
         pragma Form_Set (Using_Pointer_Alinement =>  False);
         procedure foo is
         begin
           null;
         end foo;
